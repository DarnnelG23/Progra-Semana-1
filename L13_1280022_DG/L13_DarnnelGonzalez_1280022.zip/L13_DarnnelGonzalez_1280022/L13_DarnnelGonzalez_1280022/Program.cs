﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L13_DG_1280022
{
    class MATRIZ
    {
        static void Main(string[] args)
        {
            int A = 0;
            int B = 0;
            int C = 0;
            Random numeroRandom = new Random();
            int[,] SUM = new int[5, 5];
            int[,] MULT = new int[10, 10];
        Ciclo:
            Console.WriteLine("OPCIONES: " +
            "\nA. Llenar Matriz" +
            "\n----------------------" +
            "\nB. Suma de la Matriz" +
            "\n----------------------" +
            "\nC. Tablas de Multiplicar");
            string Op;
            Op = Console.ReadLine();

            switch (Op)
            {
                case "A":
                    Console.WriteLine("Resultado Inciso A");
                    for (A = 0; A < 5; A++)
                    {
                        for (B = 0; B < 5; B++)
                        {
                            SUM[A, B] = numeroRandom.Next(150);

                        }
                        Console.WriteLine(SUM[A, 0] + ", " + SUM[A, 1] + ", " + SUM[A, 2] + ", " + SUM[A, 3] + ", " + SUM[A, 4]);
                    }
                    goto Ciclo;
                case "B":
                    for (A = 1; A < 5; A++)
                    {
                        for (B = 1; B < 5; B++)
                        {
                            C = C + SUM[A, B];
                        }
                    }

                    Console.WriteLine();
                    Console.WriteLine("Total Suma:" + C);
                    Console.ReadLine();
                    goto Ciclo;
                case "C":

                    for (A = 0; A < 10; A++)
                    {
                        for (B = 0; B < 10; B++)
                        {
                            MULT[A, B] = (A + 1) * (B + 1);


                        }
                        Console.WriteLine(MULT[A, 0] + ", " + MULT[A, 1] + ", " + MULT[A, 2] + ", " + MULT[A, 3] + ", " + MULT[A, 4] + ", " + MULT[A, 5] + ", " + MULT[A, 6] + ", " + MULT[A, 7] + ", " + MULT[A, 8] + ", " + MULT[A, 9]);
                    }
                    goto Ciclo;

                default:
                    Console.WriteLine("Porfavor intentelo de nuevo, la opcion que a seleccionado no existe");
                    break;
            }
            Console.ReadKey();
        }
    }
}