﻿// See https://aka.ms/new-console-template for more information
int[] arreglo = new int[1];
int[] vector;
int suma = 0;
int largo = 0;
int impares = 0, pares = 0;


Console.WriteLine("Cantidad de numeros a ingresar");
largo = int.Parse(Console.ReadLine());

vector = new int[largo];

for (int i = 0; i < vector.Length; i++)
{
    Console.WriteLine("Ingresar el numero");
    largo = int.Parse(Console.ReadLine());
    vector[i] = largo;
}
Console.WriteLine("Los numeros ingresados son: ");
for (int i = 0; i < vector.Length; i++)
{
    Console.WriteLine(vector[i] + "");
    suma += vector[i];
}
Console.WriteLine("Los suma total es : " + suma);
Console.WriteLine("La longitud del arreglo es de: " + largo);
for (int i = 1; i < vector.Length; i += 2)
{
    pares += vector[i];
}
Console.WriteLine("La suma de la posiciones pares es : " + pares);
for (int i = 0; i < vector.Length; i = i + 2)
{
    impares += vector[i];
}
Console.WriteLine("La suma de las posiciones impares es : " + impares);
Console.ReadKey();

