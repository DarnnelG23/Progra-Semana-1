﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB11_MarioVillanueva_1148222
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double catetoA = Convert.ToDouble(textBox1.Text);
            double anguloOpuestoA = Convert.ToDouble(textBox2.Text);
            Class1 objTriangulo = new Class1(catetoA, anguloOpuestoA);
            

            
            double catetoB;
            double area;
            double Hipotenusa;
            double anguloOpuestaA;
            double anguloOpuestaB;

            catetoB = objTriangulo.ObtenerCatetoB();
            Hipotenusa = objTriangulo.ObtenerHipotenusa();
            anguloOpuestaA = objTriangulo.ObtenerAnguloOpuestaA();
            anguloOpuestaB = objTriangulo.ObtenerAnguloOpuestaB();
            area = objTriangulo.ObtenerArea();

            label3.Text = "El cateto A: " + catetoA;
            label4.Text = "El cateto B :" + catetoB;
            label5.Text = "El hipotenusa:" + Hipotenusa;
            label6.Text = "El anguloOpuestaA:" + anguloOpuestaA;
            label7.Text = "El anguloOpuestaB:" + anguloOpuestaB;
            label8.Text = "El area: " + area;

        }
    }
}
