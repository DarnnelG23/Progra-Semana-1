﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_DG_1280022
{
    class Class1
    {
        double catetoA;
        double catetoB;
        double area;
        double Hipotenusa;
        double anguloOpuestoA;
        double anguloOpuestaB;

        public Class1 (double catA, double anguloA)
        {
            catetoA = catA;
            anguloOpuestoA = anguloA ;
        }
        public double ObtenerCatetoA()
        {
            return catetoA;
        }
        public double ObtenerCatetoB()
        {
           catetoB = catetoA/Math.Tan(anguloOpuestoA);
            return catetoB;
        }
        public double ObtenerHipotenusa()
        {
           
            Hipotenusa =  Math.Sqrt((catetoA *catetoA+catetoB*catetoB));
            return Hipotenusa;
        }
        public double ObtenerAnguloOpuestaA()
        {
            return anguloOpuestoA;
        }
        public double ObtenerAnguloOpuestaB()
        {
            anguloOpuestaB = 180- anguloOpuestoA - 90;
            return anguloOpuestaB;
        }
        public double ObtenerArea()
        {
            area = (catetoA*catetoB)/2;
            return area;
        }
         

    }
}
