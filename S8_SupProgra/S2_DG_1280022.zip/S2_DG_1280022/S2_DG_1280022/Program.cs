﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2_DG_1280022
{
    class Program
    {
        static void Main(string[] args)
        {
            string meses = "Mes";
            Console.WriteLine("Ejercicio 1");
            Console.WriteLine("Ingrese el número del mes");
            int mes = Int32.Parse(Console.ReadLine());
            if (mes < 1 | mes > 12)
            {
                Console.WriteLine("Error: el número a ingresar debe estar contenido entre 1 y 12");
            }
            else
            {
                switch (mes)
                {
                    case 1:
                        Console.WriteLine(meses + "Enero");
                        break;
                    case 2:
                        Console.WriteLine(meses + "Febrero");
                        break;
                    case 3:
                        Console.WriteLine(meses + "Marzo");
                        break;
                    case 4:
                        Console.WriteLine(meses + "Abril");
                        break;
                    case 5:
                        Console.WriteLine(meses + "Mayo");
                        break;
                    case 6:
                        Console.WriteLine(meses + "Junio");
                        break;
                    case 7:
                        Console.WriteLine(meses + "Julio");
                        break;
                    case 8:
                        Console.WriteLine(meses + "Agosto");
                        break;
                    case 9:
                        Console.WriteLine(meses + "Septiembre");
                        break;
                    case 10:
                        Console.WriteLine(meses + "Octubre");
                        break;
                    case 11:
                        Console.WriteLine(meses + "Noviembre");
                        break;
                    case 12:
                        Console.WriteLine(meses + "Diciembre");
                        break;
                }
            }
            try
            {
                Console.WriteLine("Ejercicio 2");
                Console.WriteLine("Ingrese el número 1");
                int a = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el número 2");
                int b = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el número 3");
                int c = Int32.Parse(Console.ReadLine());

                if (a < 1)
                {
                    Console.WriteLine("Debe ingresar un número mayor a 0");
                }
                else if (b < 1)
                {
                    Console.WriteLine("Debe ingresar un número mayor a 0");
                }
                else if (c < 1)
                {
                    Console.WriteLine("Debe ingresar un número mayor a 0");
                }
                else
                {
                    if (a > b)
                    {
                        if (a > c)
                        {
                            Console.WriteLine("El número mayor es: " + a);
                        }
                        else if (a == c)
                        {
                            Console.WriteLine("El número mayor es: " + a);
                        }
                    }
                    else if (a == b)
                    {
                        if (a > c)
                        {
                            Console.WriteLine("El número mayor es: " + a);
                        }
                        else if (a == c)
                        {
                            Console.WriteLine("El número mayor es: " + a);
                        }
                    }
                    else if (b > c)
                    {
                        Console.WriteLine("El número mayor es: " + b);
                    }
                    else if (b == c)
                    {
                        Console.WriteLine("El número mayor es: " + b);
                    }
                    else
                    {
                        Console.WriteLine("El número mayor es: " + c);
                    }
                }


            }
            catch
            {
                Console.WriteLine("Debe ingresar un número");
            }
            Console.ReadKey();
        }

    }
}